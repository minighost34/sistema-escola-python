from psycopg2 import Error
from conexao import conectar_banco

def deletar_aluno():
    conn = conectar_banco()

    if conn is None:
        print("Não foi possível conectar ao banco.")
        return

    cursor = conn.cursor()

    id_aluno = input("Digite o ID do aluno que deseja excluir: ").strip()

    sql = "DELETE FROM alunos WHERE id = %s"

    try:
        cursor.execute(sql, (id_aluno,))
        conn.commit()

        if cursor.rowcount > 0:
            print("Aluno excluído com sucesso!")
        else:
            print("Nenhum aluno encontrado com esse ID.")
    except Error as e:
        print(f"Erro ao excluir aluno: {e}")
    finally:
        cursor.close()
        conn.close()