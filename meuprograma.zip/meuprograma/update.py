from psycopg2 import Error
from conexao import conectar_banco

def atualizar_aluno():
    conn = conectar_banco()

    if conn is None:
        print("Não foi possível conectar ao banco.")
        return

    cursor = conn.cursor()

    id_aluno = input("Digite o ID do aluno: ").strip()
    novo_nome = input("Novo nome: ").strip()

    sql = "UPDATE alunos SET nome = %s WHERE id = %s"

    try:
        cursor.execute(sql, (novo_nome, id_aluno))
        conn.commit()

        if cursor.rowcount > 0:
            print("Aluno atualizado com sucesso!")
        else:
            print("Nenhum aluno encontrado com esse ID.")
    except Error as e:
        print(f"Erro ao atualizar aluno: {e}")
    finally:
        cursor.close()
        conn.close()