from psycopg2 import Error
from conexao import conectar_banco

def cadastrar_aluno():
    print("Entrou em cadastrar_aluno()")

    conn = conectar_banco()

    if conn is None:
        print("Não foi possível conectar ao banco.")
        return

    cursor = conn.cursor()

    print("\n--- Cadastro de Aluno ---")
    nome = input("Nome: ").strip()
    data = input("Data de nascimento (DD/MM/AAAA): ").strip()
    cpf = input("CPF: ").strip()

    sql = """
    INSERT INTO alunos (nome, data_nascimento, cpf)
    VALUES (%s, %s, %s)
    """

    try:
        cursor.execute(sql, (nome, data, cpf))
        conn.commit()
        print("\nAluno cadastrado com sucesso!")
    except Error as e:
        print(f"Erro ao cadastrar aluno: {e}")
    finally:
        cursor.close()
        conn.close()