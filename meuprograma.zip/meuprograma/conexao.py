import psycopg2

def conectar_banco():
    try:
        return psycopg2.connect(
            "host=localhost dbname=escola user=postgres password=1234 port=5432 connect_timeout=3"
        )
    except Exception as erro:
        print("Erro ao conectar:", repr(erro))
        return None